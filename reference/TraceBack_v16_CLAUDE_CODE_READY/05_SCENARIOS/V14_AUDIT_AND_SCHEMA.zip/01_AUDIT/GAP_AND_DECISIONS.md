# Claude 구현 전 의사결정 잠금표

| 우선 | 질문 | 권장 기본안 | 확정 상태 |
|---|---|---|---|
| P0 | canonical vehicle model? | v14 `stepIntegratedVehicle`; actuator-lab는 참고/구형 호환, 중복 실행 금지 | RECOMMENDED |
| P0 | 블록 퍼즐 무엇을 수정하는가? | validated limited mutation slots. `TorqueLimitSelector`, `FanHysteresis`, `RegenFrictionCompensation` 등 허용 지점에서 실제 계산식을 교체 | PROPOSED; ENGINE PATCH NEEDED |
| P0 | 첫 사건의 실제 버그/비정상 신호? | 정상 보호 제약 vs SW 단위/제한 해석 오류. safety override 제거 정답 금지 | CASE NOT LOCKED |
| P0 | 정상 기준(oracle)? | 독립 요구사항 기대값 + 기준 모델 스냅샷 비교, expected trace computed and audited | NOT VERIFIED |
| P0 | test vectors? | 20ms tick input series, time-indexed fault window, reset between twins | NOT CREATED |
| P0 | 2개 필수 고장 발생과 조기 체포 충돌? | 두 사건 전 조기 체포 판정 보호 **또는** early caught replay로 사건 수 조건 명확히 구분 | USER DECISION NEEDED |
| P0 | 해결 못해도 다음 사건? | 완전 복구 미통과 시 제한 주행/안전한 대체 경로로 진행. 안전 조건이 불가하면 narrative exit 별도 | PROPOSED |
| P0 | 새 와이어프레임 버전? | actual HTML 있는 2개 ZIP을 UI 구조 우선 레퍼런스로, 15~21 이미지 ZIP은 이미지 스타일 모음만; 최종 승인 화면 선택 필요 | USER DECISION NEEDED |
| P0 | 실제 3D 에셋/맵? | 원본 reference images와 3D runtime asset을 분리; 3D는 임시 procedural model + exchangeable slots | NEEDS AUDIT |
| P1 | 차고 4계층의 각 도메인 표현? | 모든 도메인 explorer 표시, 대표 가속 기능 4계층 인터랙션 1회 | RECOMMENDED |
| P1 | 사건당 가설과 시험 수? | 2~3 hypotheses, 3~4 evidence, 2 required tests + 1 optional | PROPOSED |
| P1 | 힌트/fail? | 동일 무근거 오답 2회부터 soft hint, 3회 guided, 시험 FAIL은 유익한 관측이지 game over 아님 | PROPOSED |
| P1 | 세 번째 보너스 사건? | 브레이크 배분, optional but no final exam | PROPOSED |
| P1 | 3D racing camera/collision? | playable first, scene composition QA for rich harbor; no big Git import | RECOMMENDED |

## 게임 상태 계약 최소
`GARAGE → RACE → FAULT_1 → ASSIST_DRIVE → INVESTIGATE → LOGIC_EDIT → TWIN_TEST → REPAIR_OR_LIMIT → RACE → FAULT_2 → ASSIST_DRIVE → ... → OPTIONAL_FAULT_3? → FINAL_RACE → ESCAPE|CAUGHT`
- incident1/2 must both be *triggered*; whether solved can vary. Forbid arbitrary scene select/retry checkpoint after Caught per recent user constraints.
- investigation UI is assisted low-speed visual driving; distinguish display animation from actual chase position/time. Real chase meter must derive from physical relative positions or explicit model with documented distance dynamics, not arbitrary points pretending meters.
- no mandatory numeric typing; short Korean sentence blocks; safety constraints cannot be disabled by puzzle.

## 48-hour gate
**PASS 1**: beautiful-enough 3D controllable drive + 4 layer garage snapshot + one incident proof of causal patch + one actual test/test regression path.
**PASS 2**: second incident + 2nd timing-focused puzzle + required second fault event before finale + optional bonus as stretch. All other domains exist as canonical engine signals/explorer, NOT individually playable cases.
