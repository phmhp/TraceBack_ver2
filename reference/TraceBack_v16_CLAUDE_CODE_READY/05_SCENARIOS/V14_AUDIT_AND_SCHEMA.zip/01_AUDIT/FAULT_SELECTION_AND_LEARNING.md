# 고장 사건 선정 근거와 점수표

## 일차 소스 (강한 근거 → 약한 근거)
1. 첨부 v14 함수/테스트: 기술적으로 실행/관측 가능한지. 가장 강한 로컬 구현 근거.
2. MathWorks 공식 EV Reference Application: supervisory torque, regenerative braking, BMS dynamic charge/discharge limit 등 *교육 모델 원리* 확인: https://www.mathworks.com/help/autoblks/ug/explore-the-electric-vehicle-reference-application.html
3. VDA-QMC Automotive SPICE PAM v4.0: 요구사항·검증 측정·선정·판정·추적성: https://vda-qmc.de/wp-content/uploads/2023/12/Automotive-SPICE-PAM-v40.pdf
4. NHTSA complaint/recall/defect public data: 실제 증상·고장 유형의 **스토리 영감** (특정 사례의 OEM 원인으로 연결하려면 반드시 조사 보고서/리콜 근거 별도 확인): https://www.nhtsa.gov/nhtsa-datasets-and-apis
5. 자체 가상 설계: 누락 블록·mutation 버그, 게임 고양이 연출, 2~3 후보 가설은 교육용 창작. 실차에서 실제로 발생한 특정 오류라고 주장 금지.

## 후보별 점수 기준 (각 0~3점)
- 제어 원리 대표성 (signal→state→limit→actuator)
- 결함 재현 가능성 (v14에 mutation injection 구현 가능성)
- 가설 구분력 (2+ hypotheses, discriminating signals)
- 독립 검증 가능성 (oracle, boundary, fault, normal regression)
- 게임 가시성 (차량 동작/장치 움직임/가상 파형)
- 안전교육 적합성 (안전 제한 무력화가 정답이 아님)
- 개발 효율 (기존 모델/테스트/자산 재사용, 높을수록 간단)

## 잠정 평가 (코드 확인 기반 정성 점수, 실증 평가 아님)
| 사건 | 대표 | 재현 | 구분 | oracle | 시각 | 안전 | 효율 | 합계 /21 | 판단 |
|--|--:|--:|--:|--:|--:|--:|--:|--:|--|
| 토크 제한 해석 오류 | 3 | 2 | 3 | 2 | 3 | 3 | 2 | 18 | 필수1 후보 |
| 팬 히스테리시스 SW 오류 | 3 | 2 | 3 | 3 | 3 | 3 | 2 | 19 | 필수2 후보 |
| 회생/마찰 보완 오류 | 3 | 2 | 3 | 3 | 3 | 3 | 2 | 19 | 선택3 후보 |
| 단순 팬 HW 고착 | 2 | 3 | 3 | 3 | 3 | 3 | 3 | 20 | SW 블록 퍼즐 목표와 상충, HW 사건 대안 |
| 통신 타임아웃 | 3 | 3 | 2 | 3 | 2 | 3 | 3 | 19 | 교과서적 심화 후보 |

**선택 기준은 합계만으로 결정하지 않는다.** 필수 두 사건은 서로 다른 검증 사고(공간적 신호 추적 vs 시간/상태 검증)를 요구해야 함. 명확한 검증 oracle 없는 사건은 시나리오 출시 금지.

## 사례 팩 완성 조건
1. 소스 provenance 확인 (v14 함수/요구사항 문서/보정값의 출처)
2. 2개 경쟁 가설이 *실제 로그에서 구분 가능*함을 확인. `hypothesis H1/H2`에서 같은 결과만 나오면 사례 폐기/수정.
3. fault injection이 하나의 명시적인 단계/계층에 위치하고 정상 reference와 달라야 함.
4. 같은 초기 state, dt=.02, 동일 inputs에 대해 reference/faulty/repaired 3개 trace 생성.
5. 실패 원인을 노출하지 않고도 증상 2~4개 관측 가능.
6. 고장조건에서 문제 재현, 정상조건에서 정상이었음을 재현, 수리 후 고장/정상/경계 regression 통과.
7. 타이밍/피드백 tolerance 및 safety outcome 검증.
8. repair UI가 실제 수정한 제어 계산과 연결; UI-only success는 불허.
9. 게임에서 2~5분에 추리 가능 (컨텐츠/힌트 길이 검토).
10. 해당 사건의 회귀 증거/테스트 로그를 별도 파일로 추적.
