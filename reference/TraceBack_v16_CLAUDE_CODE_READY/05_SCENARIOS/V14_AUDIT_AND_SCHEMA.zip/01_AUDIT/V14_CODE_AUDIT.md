# v14 실제 소스 감사

자료: 사용자가 첨부한 `TraceBack_v14_REUSABLE_CONTROL_CORE(1).zip`; 65 entries. 제어 모델을 정적으로 살펴보고 포함 테스트를 실행함. 다른 전체 원본 프로젝트나 최신 개발 브랜치는 검증하지 않음.

## 검증
- `node --experimental-strip-types --test tests/*.test.mjs` (Node v22.16.0): tests 323, pass 321, fail 2, skip 0.
- `tests/engineering.test.mjs`와 `tests/logic.test.mjs`는 `src/content/ready.ts`가 선별 ZIP에 없어 **import 로딩 실패**. 도메인 계산 assertion 실패가 아님.
- 이 ZIP은 package.json/빌드/전체 UI를 포함하지 않아 TypeScript 타입검사, 게임 번들, 브라우저, GPU 및 e2e 검증 미수행.

## 구현 수준을 코드 파일 기준으로 나눔
| 영역 | v14 확인 내용 | 빠진 내용 / 정직한 한계 |
|--|--|--|
| BMS (`bmsModel.ts`) | SOC, 셀 전압, 온도, current/power 제한, 충방전 상한, 상태 복귀 | cell estimator/SOH, 전기화학/셀 밸런싱, 실제 센서/물리 모사 없음 |
| HV (`hvModel.ts`) | OFF/PRECHARGE/CONTACTOR_CLOSE/HV_READY/FAULT, 피드백, 타임아웃, HV plant | 실물 접촉기 안전 검증 아님 |
| Vehicle mode (`vehicleModeModel.ts`) | OFF/INIT/HV_PREPARING/READY/DRIVE/DEGRADED/FAULT | 실차 VCU 전체 시스템 상태기 아님 |
| Gear (`gearInterlockModel.ts`) | P/R/N/D 허용, SHIFTING/FAULT, 피드백/타임아웃, 지연 plant | 물리 기어/파킹 시스템 충실도 없음 |
| Propulsion (`propulsionModel.ts`) | 페달 A/B·신선도, 차속 요구 맵, BMS 제한, slew, 명령·모터 plant·진단 | 인버터 전류/PWM, 4사분면 구동/회생 통합, drivetrain/타이어 거동 없음 |
| Brake (`brakingModel.ts`) | 회생/마찰 배분, 충전전력 한계, 저속/ABS 요청 제한, 피드백 지연·결함 | ABS 휠 슬립 폐루프, ESC/yaw, 회생/마찰 축별 제어 아님 |
| EPS (`epsModel.ts`) | 속도별 보조, 온도·전류 제한, 명령·plant 피드백 | yaw/steering rack/tire dynamics 없음 |
| Thermal (`thermalModel.ts`) | 팬/펌프 hysteresis, staged demand, 온도 plant, derate, time fault | 실제 열회로·냉각수 유동·배터리 상세 열해석 아님 |
| LV (`lvPowerModel.ts`) | DC/DC enable, LV 전압, 부하 관리, 전압/전원 plant fault | 대용량 load model/electrical networks 없음 |
| Communications (`communicationDiagnosticsModel.ts`) | range, timeout, message validity, plausibility, tracking, debounce·recovery | 실제 CAN/LIN/Ethernet stack, frame scheduling, DTC/UDS stack 없음 |
| Cross-domain (`integratedVehicleModel.ts`) | 20ms tick, previous feedback, BMS→VCU/regen, thermal derate, brake override, separate actuals | 단순 가속도 추정만 있음, 실제 속도·경로·타이어·추격·3D 없음 |
| Blocks (`signalBlocks.ts`) | 그래프/연산 자료 존재 | user-authored graph가 `stepIntegratedVehicle` 결과를 직접 바꾸는 연결 증거 없음 |
| Legacy actuator (`actuator-lab/engine.mjs`) | 독립 경량 사건/관측 실행 | v14 canonical integrated engine과 병렬, 자동 병합 위험 |

## 차량 거동 영역의 정확한 경계
- 이 모델은 drivetrain torque 및 제동력을 `longitudinalNetForceN` → `accelerationEstimateMs2`로 환산할 뿐 속도/위치/요각, 타이어 마찰 한계, ABS/ESC/TCS 폐루프, 코너링, 지면 접촉 및 충돌을 소유하지 않는다.
- '차량 거동의 모든 도메인을 다 구현'은 NO. '일반 EV ECU 제어의 대표적인 교육용 골격을 폭넓게 모델링'은 YES.
- **권장 추가 계층:** game 3DOF or arcade chassis (속도, position, steering/yaw, tire grip, collision), interface adapter that takes torque/force steering requests. Avoid representing game physics as certified vehicle model.
- **선택 확장:** wheel-slip based simplified ABS/TCS and basic ESC yaw correction (교육 목적/예외 테스트), charging/OBC/plug state (차고 소개). These are missing domains, not blockers for basic arcade prototype.

## 가장 중요한 통합 갭 (P0)
1. 사용자 편집 SW 문장 블록의 수정 내용이 canonical `stepIntegratedVehicle`에 실제 반영되도록 explicit patch-point 설계. 기존 엔진과 독립적인 데모 엔진을 숨겨 돌리지 말 것.
2. 결함 주입 세 종류: (A) sensor/interconnect, (B) controller decision mutation, (C) plant/hardware fault. v14 `plantFaults`는 (C)만 지원. (B) 결함/수정 경로는 별도 설계 필요.
3. `reset`/`step`/`snapshot`/`trace`로 공통 테스트 하네스: same initial state, same inputs, fault window, same dt, same deterministic seed.
4. oracle 근거. 테스트마다 `requirementId`, `observables`, `tolerance`, temporal assertion, pass/fail reason, original regression test.
5. 게임 chase의 속도/거리와 vehicle outputs가 동작하는 신호 단위로 연결되되 arcade player controls and safety fallback remain game-safe.

## 검증 교육 갭
- 단순 PASS/FAIL 대신 요구사항과 관측·정상 기대·시간·원인 후보·증거가 같은 사건 id에 귀속되어야 함.
- '시험 카드'의 정답은 수치 암기가 아니라 진단적 구분력 (hypothesis discriminating power): 어떤 시험이 원인 둘을 갈라놓는가.
- 단위/연동/시스템 개념은 교육용 범위 라벨로만 사용. SIL/PIL/HIL 진짜 시험으로 명명 금지.
- 테스트 환경 오류/NaN/누락은 MODEL_ERROR로 구별, 플레이어 오답 금지.
