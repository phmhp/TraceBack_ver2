# 사건 데이터 생성·검증 워크플로

### 1. 요구사항과 실제 신호 정의
- v14 모델의 `stepIntegratedVehicle()` 출력 경로, controller input/output, 단위와 소유 ECU를 `signal_dictionary.csv`에 작성.
- `requirements.csv`: requirementId,ownerLayer,ownerDomain,shallStatement,precondition,expectedBehavior,acceptanceMethod,sourceRef,status
- 실제 스펙이 없는 교육용 값은 `FICTITIOUS_EDUCATIONAL_CALIBRATION`으로 라벨링.

### 2. 결함 유형 선택
- `HARDWARE_PLANT`: `plantFaults`에 fanStuckOff, motorStuck, brake.stuckFriction 등이 직접 존재.
- `SENSOR_SIGNAL`: 통합 입력값과 `signalAgeMs`, per-signal age, diagnosticObservation 변경. 정상/비정상 validity.
- `INTERFACE`: 단위/신호 선택/갱신 간격의 결함을 테스트 하네스로 명시적으로 주입; 허용된 한 위치만 변경.
- `SW_DECISION`: v14 현재 핵심 변경. *controller mutation slot*를 명시적으로 만들고 특정 분기/연산자를 reference vs faulty vs repair 세 버전으로 시험. UI에서 바꾼 블록이 실제 `stepIntegratedVehicle`의 계산에 반영되지 않으면 사건 사용 불가.

### 3. 시험 벡터 생성
- `trace_reference.csv`, `trace_faulty.csv`, `trace_repaired.csv`: 각 row에서 timeSec,tick,testId,signalId,value,unit,sourceLayer,origin (MEASURED/ECU_CALCULATED/ECU_COMMAND/PLANT_ACTUAL) 기록.
- 같은 testId에 대해 state reset 후 20ms로 연속 실행. 두 시험대에서 초기상태와 입력 시퀀스/seed 동일.
- 출력 비교 시 센서 현재 입력과 previous tick plant 측정값을 혼동하지 않음. transient grace / settle window 미확인 시 판정 보류.
- test vector는 `inputSeriesRef`에서 버전 관리된 CSV/JSON을 가리킴.

### 4. 오라클 생성
- 단순 기준 모델 output copy 금지. `expectedFrom`에 어떤 요구사항, 독립 수식, verified reference test에서 도출했는지 기록.
- 시험마다 numericalTolerance, temporal window, expected transitions, oracleVersion / modelHash 저장.
- 판정: `PASS` 요구사항 충족, `FAIL` 위반, `INCONCLUSIVE` 근거 부족, `MODEL_ERROR` 모델/데이터 잘못. 가설 상태 `SUPPORTED/REFUTED/UNRESOLVED`는 별도.

### 5. 게임 팩 제작
- `scenario.json`: 고장/가설/증거/테스트/수리/연출/힌트/복귀 조건.
- 구간별 reveal permissions: FAULT_CUE→REPLAY→INSPECTION→TWIN_TEST. 모든 증거를 처음부터 제공 금지.
- 메모판: 구분 신호 최소 1개 선택; 로직: 실제 patch에 연결되는 1~2 block choice; 시험: discriminating card 1개 + regression card 1개.
- `sourceBasis[]`에서 게임 아이디어와 검증된 실제 코드 사실을 명확히 구분.

### 6. 릴리스 게이트
- Proposed JSON은 실행용 파일로 투입하지 않음. `TRACE_VERIFIED` 이상만 데모 기본 경로에 등록.
- `GAME_VERIFIED` 승격 조건: UI selection→logic mutation→differential trace→verdict→repair→return to race까지 e2e 통과.
- 시나리오 추가시 UI 코드를 복제하지 말고 동일 `scenario.schema.json`과 generic scenes 재사용.

## 최소 추가 실데이터 파일 목록
- `signal_dictionary.csv`  (정의된 v14 신호 경로/단위)
- `requirements.csv` (REQ 레벨/한 줄 명세/오라클)
- `test_vectors/<case>-<test>.json` (초기상태, 입력 시계열, 주입 이벤트)
- `traces/<case>-reference.csv`, `-faulty.csv`, `-repaired.csv`
- `cases/<case>/scenario.json` (CASE-01..03)
- `coverage_matrix.csv` (reqId,testId,boundary,negative,recovery,status)
- `reproducibility.json` (v14 source SHA, calibrationVersion, run tool, dt, seed)
