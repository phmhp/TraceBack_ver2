from pathlib import Path
import json,sys
try:import jsonschema
except ImportError:
 print('Install jsonschema: python -m pip install jsonschema');sys.exit(2)
root=Path(__file__).resolve().parents[1]
schema=json.loads((root/'02_SCENARIO_SCHEMA/scenario.schema.json').read_text())
ver=jsonschema.Draft202012Validator(schema)
errors=0
for p in sorted((root/'03_SCENARIO_DRAFTS').glob('*.json')):
 d=json.loads(p.read_text());issues=[e.message for e in ver.iter_errors(d)]
 evid={e['signalId'] for e in d.get('evidence',[])}
 tid={t['testId'] for t in d.get('tests',[])}
 for h in d.get('hypotheses',[]):
  issues += [f"{h['id']} discriminator not present in evidence: {s}" for s in h['discriminatorSignalIds'] if s not in evid]
 for r in d.get('repair',{}).get('regressionTestIds',[]):
  if r not in tid:issues.append('unknown regression test '+r)
 if d.get('status') in ('TRACE_VERIFIED','GAME_VERIFIED'):
  for t in d.get('tests',[]):
   if t['inputSeriesRef'] is None or any(a['value'] is None or a['unit']=='PENDING' for a in t['assertions']):issues.append('NOT_READY_TEST_VECTOR_OR_ORACLE:'+t['testId'])
 if d.get('status')=='PROPOSED':print(f'{p.name}: VALID PROPOSAL (NOT RUNNABLE)')
 elif issues:print(f'{p.name}: FAILED:',issues)
 else:print(f'{p.name}: READY FOR FURTHER REVIEW')
 if issues:errors+=1;print('\n'.join(issues))
sys.exit(1 if errors else 0)
