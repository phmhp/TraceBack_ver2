# scenario.schema.json의 검증 강제사항

- 파일 내 `status = PROPOSED`는 고장 콘텐츠 아이디어일 뿐 실행 중인 코드·완성된 trace가 아님.
- `inputSeriesRef=null` / `value=null` / `unit=PENDING`가 존재하는 동안 해당 케이스는 playable scenario registry에 등록 금지.
- `sourceBasis`에서 VERIFIED_IN_SOURCE는 그 **코드 기능**의 존재만 의미하고 사례 mutation 구현을 보장하지 않음.
- 테스트 벡터가 시간/초기 상태/통신 신호 age/plant feedback을 모두 포함한 경우에만 valid.
- `assertions`의 비교는 signalId 단위·abs/rel tolerance·시간 구간을 포함해야 함. Boolean & transition은 다른 oracle 종류 사용.
- 같은 `testId`에 대해 `reference/faulty/repaired`에서 초기조건/입력시퀀스가 동일함을 checksum으로 확인.
- `hypotheses[].discriminatorSignalIds`는 case `evidence[].signalId`에 존재해야 함.
- `repair.regressionTestIds`는 tests에서 NORMAL/RECOVERY 검증에 연결되어야 함.
- 아래 예제 3개는 정규 형식의 **설계 초안**이지 검증된 실제 결함 데이터가 아니다.
