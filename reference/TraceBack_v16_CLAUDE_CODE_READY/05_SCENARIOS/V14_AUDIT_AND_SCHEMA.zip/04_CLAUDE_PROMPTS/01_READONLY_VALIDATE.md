# Claude Code PASS 0: 읽기 제한 및 실제 소스 확인

기존 대형 Git 저장소를 읽지 마. 제공된 `TraceBack_v14_REUSABLE_CONTROL_CORE(1).zip`과 이 계약 디렉터리만 사용해. 전체 Stitch 이미지 ZIP·170MB 에셋 ZIP을 덤프하지 마.

1. `00_README_FIRST.md`, `01_AUDIT/V14_CODE_AUDIT.md`, `01_AUDIT/GAP_AND_DECISIONS.md`, `02_SCENARIO_SCHEMA/DATA_PIPELINE.md`부터 읽어.
2. v14 코어에서 `integratedVehicleModel.ts`, 3개 사건 관련 `propulsionModel.ts`, `thermalModel.ts`, `brakingModel.ts`, BMS 및 관련 테스트만 읽어.
3. 기존 `signalBlocks.ts`, `actuator-lab/engine.mjs`와 canonical 실행기의 중복 책임을 1페이지 표로 비교하고 어느 인터페이스를 사용해야 하는지 제안. 근거 없이 전부 병합하거나 복제하지 마.
4. 두 필수 고장과 보너스 사건 3개 JSON의 각각에서 실제 v14로 가능한 것/추가 구현해야 하는 것/정답 값 미확정을 3열로 표기.
5. 테스트를 실행하고 실패한 것은 실제 계산 실패와 missing dependency/import를 구분해.
6. 지금 단계는 UI 구현/에셋 로딩/새 게임 코딩하지 마. 결과는 최대 1500자와 source paths만 남겨.

필수 P0 질문: 직접 편집 그래프가 어느 실제 controller 계산 단계에 연결되는가? 같은 입력·초기상태로 reference/faulty/repaired를 생성할 수 있는가? game distance m와 toy model 속도/힘은 어떤 계층에서 연결하는가?
