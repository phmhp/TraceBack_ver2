# Claude Code PASS 1: 실제 동작하는 단일 사건 수직 슬라이스

전제: PASS0의 기술 갭을 확인했으며 이번 패키지의 proposed 사건 원인/수치는 아직 확정되지 않았음.

새 작업 저장소에서 개발. 이전 Git 저장소 전체로 돌아가지 마. Stitch 와이어프레임1/2의 HTML은 주UI 참고; 15~21 ZIP은 이미지 레퍼런스이며 실제 HTML 구현이 아님. 승인 화면 08-01/02/03에 해당하는 파일/캡처만 열어.

1. React/Three.js 또는 현재 프로젝트에 맞는 단일 웹 3D 스택으로 16:9 플레이 가능한 레이싱/항구 맵을 만들고, 모델·아트의 교체 가능한 슬롯을 둬. 직접 WASD/가감속/조향/장애물 회피가 되어야 함. 너무 빈 맵 금지: 도심-컨테이너항-해안-선박의 여러 근·중·원경 오브젝트.
2. 고양이 두 명: 호빵이 드라이버, 흰둥이 엔지니어. 4계층 차고 (시스템→E/E→SW아키텍처→상세설계)와 도메인 explorer. 모든 도메인 상세 미니게임 의무화 금지.
3. canonical vehicle backend = v14 `stepIntegratedVehicle`를 wrapper로 호출. controller patch slot에서 SW 퍼즐 블록이 **실제 명령**을 변경하고 toy plant 응답에 따라 reference/faulty/repaired trace가 변하게 해. 기존 `engine.mjs` 더미 verdict 엔진을 병렬 실행하지 마.
4. `CASE-01`은 JSON `PROPOSED` 상태라서 baseline source→fault injection→oracle vectors→independent checks→repaired outcome 순서로 검증된 뒤 `TRACE_VERIFIED`로 승격. 완성 전에 숫자·정답을 임의로 user-visible lore로 고정하지 마.
5. 08-01 메모판: 각 증거와 가설이 실제 trace/signalIds에서 생성되어야 함. 미끼/모호 증거는 반증 가능 조건이 있는 경우에만.
6. 08-02 제어 작업대: 짧은 자연어 요구사항, 1~2개의 제한된 SW condition/command block 연결, HW icon은 signal path 학습. 구조 오류는 차단하되 논리 오류는 시험 허용.
7. 08-03 쌍둥이 시험대: 동일 초기상태/같은 입력 20ms, faulty/current와 verified reference 비교, NORMAL/BOUNDARY/FAULT test card 중 의미 있는 조건 선택, FAIL 위치와 원인 분석, 선택형 회귀.
8. 고장 2회는 모두 **발생** 필수(둘 다 해결 필수로 오해 금지); 3회차 optional. 메모판 동안 운전자가 보조 주행 연출. 거리 m는 기하학적 상대 위치/명시적 동역학 기반만 사용. 조기 체포의 보장 문제는 미확정이므로 임의로 게임 정책을 바꾸지 마.
9. `MODEL_ERROR`를 오답으로 처리하지 말 것. 테스트 PASS는 특정 요구사항 검증에만 해당; 실제 차량 기능안전 인증/SIL/PIL/HIL 아님.
10. 테스트 자동화: 정상 기준에선 PASS, mutant는 구분 테스트에서 FAIL, repaired는 결함+회귀 통과, 잘못된 센서/plant fault는 올바른 HW 진단 경로, 변경 후 레이싱 차량 반응 달라짐.

출력: `RUN.md`(설치·실행), `STATUS.md`(실제 구현/미완), 콘솔 테스트 기록, 주요 화면 캡처. 외형만 있는 더미는 구현 완료로 기록 금지.
