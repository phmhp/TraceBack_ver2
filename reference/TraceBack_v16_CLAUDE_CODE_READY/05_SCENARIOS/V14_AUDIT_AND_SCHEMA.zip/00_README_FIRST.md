# TraceBack v14 → 검증 중심 게임: 인계 준비 패키지
작성: 2026-11-03 | 상태: source-audited / case-ideas PROPOSED / simulation traces NOT VERIFIED

## 읽는 순서
1. `01_AUDIT/V14_CODE_AUDIT.md` : 실제 확인된 구현 내용과 부족한 범위
2. `01_AUDIT/GAP_AND_DECISIONS.md` : 구현 전 결정해야 할 P0/P1 사항
3. `02_SCENARIO_SCHEMA/scenario.schema.json` : 사건을 추가할 때 지킬 데이터 형식
4. `03_SCENARIO_DRAFTS/*.json` : 고장 사례 제안. 정답 데이터 아님
5. `04_CLAUDE_PROMPTS/01_READONLY_VALIDATE.md` → `02_VERTICAL_SLICE.md` : 2단계 개발 지시
6. `05_REFERENCE_INDEX/UPLOADED_WIREFRAMES.csv` : Stitch 목업/참고 자산 목록

## 실행에서 보장되지 않는 내용
- 이 패키지는 게임을 구현하지 않음. 기존 v14 코어 ZIP도 자동 병합하지 않음.
- 사례 초안의 hypothesis/bug description은 제안이며 v14에 내장된 결함이 아님. `mutation` 및 oracle을 구현/검증해야 함.
- v14 파일의 323 테스트 실행 시 321 통과, 2개 파일은 누락된 프로젝트 파일을 import하다 로딩 실패. 완성 게임 회귀 결과 아님.
- Stitch 15~21 ZIP은 주로 이미지 참고자료, `와이어프레임1/2`는 각각 10/12개 `code.html`을 보유. 이 파일들이 일관된 최종 승인 화면인지 확인 필요.

## 절대로 혼동하지 말 것
- 사건 발생 != 사건 해결. 필수 고장 2회가 반드시 발생해야 한다는 요구는 사건의 자동 해결을 요구하지 않음.
- 모델에서 실제 ECU 명령과 toy plant 응답을 구분. toy response != real-world vehicle/HIL.
- 안전한 보호 제한 자체를 결함으로 간주하지 않음.
- req 검증 FAIL != 추리 가설 반증 != 플레이어 게임오버.
- 게임이 안정적으로 운행되는지 확인하는 간단한 vehicle movement layer와 formal SW validation level을 혼동하지 않음.
