# TraceBack v14 — 도메인별 Scenario Contract 초안 및 콘텐츠·코드 분업

## 무엇을 담았는가
- `scenarios/*.json`: 주요 EV 교육용 제어 범위 11개에서 고장 사례 후보 각 1개. 기존 Scenario Contract v1.0 스키마 준수.
- `SCENARIO_INDEX.csv`: 도메인별 목록과 실제 검증 상태.
- `tools/scenario.schema.json`: 기존 v14 시나리오 패키지와 같은 검증 스키마.
- `docs/01_GAME_FLOW.md`: 확정 게임 구조를 훼손하지 않는 순서·분기·화면 공개 정보.
- `docs/02_SCREEN_CONTENT_OWNERSHIP.md`: ChatGPT/사용자/Claude Code 책임과 Stitch 디자인 참고 원칙.
- `docs/03_DATA_PIPELINE_SIMPLIFIED.md`: 8개 파일을 손으로 작성하지 않고 생성·검수하는 흐름.
- `docs/04_SOURCE_AND_SCOPE.md`: 기능적 근거와 게임 고장 사례의 근거를 엄격히 구분.
- `docs/05_CLAUDE_IMPLEMENTATION_GATE.md`: 기술 데이터가 준비되기 전/후 Claude에게 할 일.
- `docs/06_DECISION_BOARD.md`: 앞으로 사용자 확정이 필요한 항목.

## 주의사항
- v14의 주요 모델 파일은 실제로 확인했지만, 여기 정의한 11개 고장 원인 자체가 구현되거나 trace로 재현되었다고 주장하지 않는다. 모두 `PROPOSED`.
- JSON의 `PENDING_*`은 의도적으로 미확정된 필드다. 임의 숫자·PASS·고장 로그로 대체하지 말 것.
- 세 필수 플레이 사건 후보: CASE-05 (구동), CASE-08 (열관리) / 선택형 CASE-06 (제동). 나머지 8개는 차고 도메인 탐색 및 후속 시나리오 후보.
- 각 고장 사례의 가설은 동등한 의미의 답을 반복해서는 안 된다. 확정 시 신호 구분성과 실제 재현 가능성을 확인해야 한다.
- `sourceBasis`에서 `VERIFIED_IN_SOURCE`는 해당 ECU 도메인 모델이 존재함을 의미한다. 해당 SW 버그가 존재한다는 주장이 아니다.

## 모델-시나리오 검증 단계
PROPOSED → SOURCE_REVIEWED → MODEL_IMPLEMENTED → TRACE_VERIFIED → GAME_VERIFIED

## 바로 Claude에 주는 순서
1. `docs/01_GAME_FLOW.md` + `docs/02_SCREEN_CONTENT_OWNERSHIP.md` + `docs/05_CLAUDE_IMPLEMENTATION_GATE.md`로 UI/라우팅/상태기 구현
2. `scenarios/case-05-propulsion.json`과 검증된 v14 코드·fixture에서 첫 사건 구현
3. 첫 사건이 trace-verified 되면 가속 단서/시험판정 UI 연결
4. 두 번째 CASE-08, 선택 CASE-06 순서로 확장
