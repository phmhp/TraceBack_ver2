# 데이터 8개 파일: 사람이 쓰는 것이 아니라 자동 생성하는 파이프라인

## 사용자에게 요구할 수동 작업 (최소)
1) 사건 3개 중 실제로 플레이할 원인/가설/재미·힌트·안전한 결말 승인.
2) 임시 차량·고양이 문구와 장면 순서/설명 분량 승인.
3) 기술 수치와 기대값은 임의 작성하지 말고 테스트 하네스 로그에서 검수.

## 자동 생성 순서
A. `v14`의 실제 타입·함수·결과 타입을 읽어 신호 필드 추출 (`signal_dictionary.csv` 초안). 실제 소유 ECU·단위·정확한 nested path는 코드와 대조. 출력 못 하는 필드는 PENDING.
B. v14 문서/테스트에서 요구사항을 작성 (`requirements.csv` 초안). REQUIREMENT 문장은 사람이 기술 의미를 검수; 코드 구현은 오라클의 유일한 근거가 아니다.
C. 사건별 시동/초기 상태와 입력 시퀀스 + 결함 주입점을 정의 (`test_vectors/*.json`). 정상/경계/고장/복귀가 기술적으로 구분되도록 함.
D. 동일한 고정 dt, 초기 상태, 테스트 입력을 통해 세 모델을 독립 실행: reference / faulty / repaired. 실행 시 로그를 자동 추출하여 `trace_reference.csv`, `trace_faulty.csv`, `trace_repaired.csv` 생성. `repaired`는 실제 플레이어 그래프가 ECU 계산에 반영된 경우에만 유효.
E. 실행 스크립트가 sample time/commit/model version/calibration/fault ID/seed를 `source_provenance.json`으로 생성.
F. REQUIREMENT ID와 TC ID의 매핑을 `coverage_matrix.csv`로 생성. 누락 요구사항은 채우거나 별도 NOT_COVERED 기록.

## 각 파일을 누가 만드나
signal_dictionary.csv: **자동 추출** + 사람이 단위/의미 확인
requirements.csv: **문서/테스트 기반 반자동 작성** + 도메인 의미 수동 승인
test_vectors/*.json: **시나리오 하네스 자동 생성/수정** + 경계조건 기술 검수
trace_*.csv: **실행기로 전량 자동 생성** (사람 수작업 금지)
coverage_matrix.csv: **REQ/TC 관계 자동 집계** + 누락 검토
source_provenance.json: **실행기로 자동 생성**

## 검증 게이트
- 같은 컨트롤러가 만들어 낸 값을 그대로 expected로 삼아 PASS 처리하지 말 것: 요구사항, 독립 공식/원리 계산, 또는 검증된 golden model 근거 필요.
- 비정상 조건이 나타나지 않으면 `FAULT_NOT_REPRODUCED`; 수정 후에도 실패하면 `PATCH_NOT_VERIFIED`; trace 누락이면 `MODEL_ERROR`.
- 하나의 사건이라도 reference/faulty/repaired가 특정 필수 시험에서 **의미 있게 다르다는 사실**이 확인된 뒤 게임 콘텐츠를 고정.
- 게임 내 시각화는 실제 기록인지 교육용 모형인지 구분.
