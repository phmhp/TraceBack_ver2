# 도메인 소스 근거와 실제 결함 근거의 차이

아래 소스는 `/mnt/data/TraceBack_v14_REUSABLE_CONTROL_CORE(1).zip`의 `TraceBack-develop/src/campaign/`에서 확인한 모델 존재 근거이다.

BMS `bmsModel.ts`, HV `hvModel.ts`, VehicleMode `vehicleModeModel.ts`, Gear `gearInterlockModel.ts`, Propulsion `propulsionModel.ts`, Braking `brakingModel.ts`, EPS `epsModel.ts`, Thermal `thermalModel.ts`, LV `lvPowerModel.ts`, Communication `communicationDiagnosticsModel.ts`, Integrated `integratedVehicleModel.ts`.

고장 11개는 모두 **교육용으로 주입할 후보**이며 실제 v14 코드에서 해당 버그가 발견됐다는 뜻이 아니다. 코드의 실제 예외·고장주입 API는 별도 분석 후 정확히 지정한다.

v14은 '모든 차량 도메인'을 구현했다는 주장 금지. 타이어 힘·횡방향/요 모션·노면 마찰·휠 슬립·ABS/TCS/ESC·충전/OBC/ADAS 등은 범위별로 별도 판단 필요. ECU 레벨 제어와 게임 레이싱 거동은 별도 시스템으로 분리하되 물리 응답을 독립 기록한다.

고장 출처는 다음 등급을 구분:
(1) VERIFIED_IN_SOURCE: 모델 구현 요소가 코드에서 확인됨
(2) PUBLIC_REFERENCED: 공식 기술 설명/정비 문서/리콜 조사 등 공개된 원리를 참고 (인과관계 입증 필요)
(3) EDUCATIONAL_DESIGN: 게임에 맞춰 고안한 가상 결함
(4) TRACE_VERIFIED: 실제 입력·주입·수정 결과가 자동 실행으로 확인됨

공개 증상 사례가 곧 특정 원인을 입증하지는 않는다. 하나의 사건은 최소 두 가설을 테스트로 구분할 수 있어야 한다.
