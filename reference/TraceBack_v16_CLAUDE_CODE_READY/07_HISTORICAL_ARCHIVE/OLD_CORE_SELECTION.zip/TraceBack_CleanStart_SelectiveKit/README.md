# TraceBack Clean Start — Selected Legacy Code Kit

이 ZIP은 **완성 게임이 아니라 기존 프로젝트에서 선별 추출한 로직 자료**다. 프로젝트 원본 52MB ZIP 대신 이 폴더만 전달해도 아래 검증·신호 시제품을 이해할 수 있다. 포함된 소스는 사용자 제공 `TraceBack_develop_ActuatorLogic_v3_INTEGRATED(1).zip`의 해당 원본 파일이다. 이전 대화에서 제작한 직접 로직 연결 패치는 포함되지 않는다.

## 보장된 범위
- `legacy_runtime/`: 8개 교육용 도메인 케이스와 신호망·시나리오·고장 주입 엔진의 원본 4개 파일. 내부 import가 이 폴더에서 해결됨.
- `tests/`: 해당 엔진용 원본 테스트 3개, 상대 경로만 고침. Node v22 이상에서 `npm test` (외부 npm 패키지 없이 실행 가능).
- `reference_only/torqueModel.ts`, `signalBlocks.ts`: 추가 그래프/시간 로직을 검토하기 위한 원본 TypeScript. 바로 실행 엔진에 혼합하지 않음.
- `reference_only/domainTraining.ts`, `vehicleArchitecture.ts`: 상위 요구사항·신호·차량/E/E/ECU 할당의 원본 참고. 별도 프로젝트 타입 의존성이 있으므로 복사만으로 독립 실행 안 됨.

## 주의
- 이 ZIP에는 3D 차량, 기존 주행 물리, 화면, 캐릭터, 이미지 에셋, HUD, 레이스, OTA, 물리 시뮬레이터 없음.
- `engine.mjs`는 신호 수준의 교육용 ECU/액추에이터 명령 시뮬레이터. 실제 HIL/임베디드/차량 제동 검증 아님.
- 샘플 숫자·테스트 결과를 OEM 검증 값으로 오인 금지.
- 새 게임은 `Three.js/R3F` 기반으로 16:9 구성 가능하지만 현재 원본 주행 코드 재사용 여부를 먼저 결정해야 함.
- 전체 도메인 구현은 필수이나 깊이는 서로 다름. 단순 case를 완성된 기능으로 표시 금지.
- 특정 로직을 수정할 때 증명 가능한 실행 결과와 동작 범위를 문서화할 것.

## 자료의 역할
공통 아키텍처/사용자 여정 정의는 `contracts`를 읽고, 런타임은 신규 앱에서 필요한 함수만 어댑터로 접근. `reference_only`는 AI에게 한꺼번에 모든 코드를 입력하지 말고 작업별로 읽게 할 것.
