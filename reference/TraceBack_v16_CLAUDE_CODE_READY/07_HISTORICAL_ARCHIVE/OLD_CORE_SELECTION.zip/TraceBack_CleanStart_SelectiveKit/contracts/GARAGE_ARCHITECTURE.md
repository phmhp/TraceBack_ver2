# 차고지: 자동차 계층을 탐험하는 1개의 UI 씬

핵심: 차가 어떻게 동작하는지 단 하나의 신호(운전자 페달 → 모터 토크)를 4개 설계 관점으로 확대/축소한다. 각 계층은 **관점(view)** 이지 차량 HW의 물리적 중첩 순서와 동의어가 아니다.

1. Vehicle/System (SYS.2/3 참고): 운전자 요구 → 가속 응답 요구; BMS/VCU/인버터/모터 등 기능과 경계. 요구 ID SYS-PT-01.
2. E/E Architecture / HW allocation: 페달 센서 → VCU ECU ← BMS ECU; VCU → 인버터 제어 ECU → 모터. 전력선과 통신선을 다른 모양. ECU 연결은 CAN 등에 대한 교육 추상화.
3. ECU SW Architecture (SWE.2 참고): VCU 내부 Application SWC(DriverDemand, TorqueLimit), RTE(통신 인터페이스), BSW(통신·진단 서비스)의 역할만 보여줌. AUTOSAR Classic의 범용 원리를 설명하지만 실제 AUTOSAR 스택 구동을 주장하지 않음.
4. SW Detailed Design (SWE.3 참고): pedal input validity → request → min(cap) → drive permission → rate limiter → torque command. 문장형 블록과 포트.
5. Plant/Feedback: 모터 명령과 실제 차량 반응의 차이, 테스트 결과, 이상 신호.

사용자 행동: 3D EV 클릭 → 4단 확대 뷰로 이동 → 각 계층에서 드래그/연결 1회 미니 액션 → 정상/비정상 출력이 달라짐 → 레이스 시작. 컷신/장문 독서 화면으로 분리하지 않음. 스킵 시 짧은 한 줄 개념만 보여줌.

도메인 카드 예: 배터리/BMS, HV, 차량상태, 기어, 구동, 제동, EPS, 열관리, LV/DC-DC, 통신/진단. 각 도메인은 시스템/E/E/ECU 상세 레벨에서 같은 ID를 사용한다. 모든 도메인마다 독립 4단 퍼즐을 요구하지 않는다.

추적 가능성: SYS-PT-01 → E/E-VCU-BMS → SWC-TorqueLimit → REQ-SW-PT-01 → TEST-SW-PT-01 / TEST-INT-PT-01 / TEST-VEH-PT-01.
