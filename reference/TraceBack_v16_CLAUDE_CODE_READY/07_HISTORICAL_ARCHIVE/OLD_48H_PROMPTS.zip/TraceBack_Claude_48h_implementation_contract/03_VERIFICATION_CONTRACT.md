# 검증 엔지니어링 — 엄격한 명칭과 최소 모델

## 교과 학습과 게임 모델의 차이
- 검증 대상 1 (Unit-like): SW 조건/명령 블록 실행, 경계/반례 확인. 이것만으로 실제 SWE.4 완료 주장 금지.
- 검증 대상 2 (Integration-like): BMS 출력 제한 → VCU 요청 제한처럼 서로 다른 기능/ECU 경계의 신호 교환, 단위/타임아웃/우선순위 확인. 실제 SWE.5 완료 주장 금지.
- 검증 대상 3 (System-model-like): ECU 명령 → 단순 액추에이터 피드백 → 가상 속도/가속 변화. 실제 HW 또는 검증된 plant를 사용하지 않으므로 SYS.5/HIL이라고 표기하지 말 것.
- MIL/SIL/PIL/HIL 구분을 가상 시험과 혼동 금지. 임베디드 코드 실행, 타깃 HW, HIL은 현재 범위 아님.

## 결함 입증과 수정 입증 분리
- `faultExposureTest`: 결함이 왜 발생하는지 보여주는 구별 가능한 입력 조건.
- `fixValidationTest`: 수정된 로직이 오류 상황에서 요구 동작 수행.
- `regressionTest`: 수정 전에 정상이던 기능도 그대로 유지하는지 확인.
- 무조건 3개를 세 화면으로 나누지 않음: 한 시험대에서 카트리지/자동 루틴으로 제공.

## PASS 정의
- `PASS`: 해당 요구사항/조건의 관측 출력과 기대 출력이 허용오차/시간 범위 내에서 일치.
- `FAIL`: 유효한 시험에서 불일치.
- `INCONCLUSIVE`: 신호/관측 부족해 결론 불가.
- `MODEL_ERROR`: 시험 환경·시나리오·모델 자체 문제. 플레이어 벌점 금지.
- 참조 모델 출력은 요구사항에서 독립적으로 근거를 검토해야 함. 두 그래프가 같기만 하면 PASS 처리 금지.

## 판정과 기록
모든 시험 레코드는 최소 requirementId/testId/stimulus(단위·샘플 시간)/candidateGraphVersion/expected/observed/verdict/firstMismatchSignal. 오라클 출처/버전 없는 값은 정식 검증 결과로 승인하지 말 것.
