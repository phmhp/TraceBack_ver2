# TraceBack 48-hour vertical slice 계약 (검토안, 구현 지시용)

이 폴더는 **기존 v3 프로젝트 전체를 대체하는 코드가 아닌** Claude Code가 수정 범위를 제어하기 위한 실행 명세입니다. 기존 v3 ZIP, Stitch export ZIP, 실제 사용자 승인 원본 에셋은 별도 첨부하고 경로를 알려주세요.

## 읽는 순서
1. `01_LOCKED_DECISIONS.md`
2. `02_GAMEPLAY_AND_SCREENS.md`
3. `03_VERIFICATION_CONTRACT.md`
4. `04_DATA_SCHEMA.json` (교육용 미확정 스키마, 값은 예시)
5. `05_ACCEPTANCE.md`
6. `06_CLAUDE_PASS_1.md` → `07_CLAUDE_PASS_2.md`

**금지:** Stitch HTML을 정답 데이터로 사용 / React 웹 대시보드로 게임 치환 / 기존 3D 아트나 엔진 갈아엎기 / 레벨 추가 / 3개 고장 자동 창작 / 수리 후보 선택을 직접 구성 로직으로 위장 / 완료되지 않은 시험을 PASS로 꾸미기.

첫 48시간은 완성한 게임 전체가 아니라 **보여줄 수 있는 실동작 핵심 루프**를 목표로 한다. 시간 제약으로 막히면 페이지 디자인보다 실제 실행 연결 우선. 특정 기능 미구현은 `MISSING`으로 보고해야 한다.
