# Garage — 하나의 3D 차량을 통한 4층 설계 뷰

## 교육 목표: 도메인(가로 폭) × 아키텍처/상세 설계(세로 깊이)
유저는 EV 전체 도메인을 살펴볼 수 있고, **한 대표 기능(가속/구동)**만 짧은 조립 경험을 필수로 통과한다. 나머지 도메인은 optional zoom/explore. 튜토리얼을 출발 전에 11개 기능 퀴즈로 만들지 않는다.

### 1 Vehicle/System (요구 동작/시스템 기능)
질문: '차량은 무엇을 해야 하는가?'
시각: 차 전체, 운전자 입력→가속/감속/조향 등 차량 반응. 도메인 선택: BMS, HV power, vehicle mode, gear, torque, braking, EPS, thermal, DC/DC, diagnostics, cross-domain.
행동: 차량 기능 아이콘 → 실제 차량 반응 애니메이션 연결.

### 2 E/E Architecture (물리 ECU·센서·통신·전력 경로)
질문: '어떤 물리 장치가 담당하고 어떤 신호가 오가는가?'
시각: 페달 센서 → VCU, BMS → VCU, VCU → 인버터 제어 ECU → 모터. CAN/통신, LV/HV 전원은 신호 배선과 선 종류가 다름. ECU 할당은 교육용 가정.
행동: 전력(실선)과 통신(점선), 센서(다른 패턴) 2~3개만 연결.

### 3 ECU SW Architecture (SW 컴포넌트 책임·인터페이스)
질문: 'VCU 내부 어떤 SW 기능이 판단하는가?'
시각: InputValidation → DriverDemand → TorqueArbitration → CommandOutput, monitoring/diagnostics. AUTOSAR Classic의 App/RTE/BSW는 옵션 도움말로만 제공. 실제 표준 stack 구현/양산 아키텍처로 주장 금지.
행동: 입력 검증과 토크 제한 기능 카드를 SW 컴포넌트 슬롯에 분류.

### 4 SW Detailed Design (조건문/상태기/시간/제한)
질문: '실제 조건과 연산이 무엇인가?'
시각: 정규화된 짧은 문장형 블록 (입력 유효? → READY 허용? → 요청과 상한 min → 출력). 정답 전체 순서를 flow chart에 모두 적어주지 않음.
행동: 빠진 한두 조건 블록을 선택·배선 → 미니 모터 반응 확인.

## 90초 안팎 짧은 필수 스텝 목표(사용성 가설)
도메인 훑어보기(15s) → E/E 연결(20s) → SWC 인터페이스(15s) → 상세 로직 1~2블록(25s) → 미니 차량 반응(10s). 시간 강제 타이머 아님.

## 차고에서의 검증 맛보기
화면의 조그만 요구사항 메모 한 줄: '가용 토크보다 큰 명령을 보내지 않는다'. 플레이어가 로직 구성 후 미니 시험 버튼을 누르면 정상/제한 조건에서 서로 다른 결과가 보임. 본격 검증은 사건별 쌍둥이 시험대.

## 학습 표시 한계
`System/E/E/SW Architecture/Detailed Design`은 설계 모델의 계층/관점이며 `unit/integration/system test`와 동일한 계층 구조 아님. 'E/E layer = 통합시험' 식의 1:1 대응 문구 금지.
