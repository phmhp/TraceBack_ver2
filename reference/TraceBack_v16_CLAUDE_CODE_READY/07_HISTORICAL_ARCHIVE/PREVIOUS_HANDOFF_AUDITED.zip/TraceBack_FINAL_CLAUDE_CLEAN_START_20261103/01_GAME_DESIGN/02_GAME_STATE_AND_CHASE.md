# 상태기/반복/실패/경찰 추격

## 2개의 직교 상태기
**GameFlow**: TITLE, PROLOGUE, GARAGE, RACE, FAULT_CUE, CAT_DIALOGUE, INVESTIGATION, LOGIC_BENCH, TWIN_TEST, RESTORE, OPTIONAL_OFFER, SHIP_REVEAL, RAMP, SUCCESS, CAUGHT, RESULT.
**VehicleMode**: OFF, PREPARE, READY, DRIVE, DEGRADED, SAFE_RESPONSE, RECOVERING. 두 열거형을 합치지 말 것. UI가 시험대로 바뀌었다고 ECU가 OFF가 되지 않는다.

## 단일 runState (예시 타입)
`{runId, gameFlow, vehicleMode, faultIndex, faultTriggeredIds[], faultResolvedIds[], optionalFaultAccepted, trackProgressM, carTrackM, policeTrackM, separationM, mindMode, selectedEvidenceIds[], hypothesisId, logicProgramVersion, testResults[], repairMode, escapeOutcome}`.
고장 이벤트는 각 ID당 1회만 fire, 이벤트 진행 중 중복 금지. 다음 필수 고장은 이전 처리 완료 후 주행 세그먼트 도달 시 발동. 실패 시 현재 run 완전 종료. 재시작은 모든 상태 reset.

## 필수 고장 두 번의 의미
두 고장 이벤트가 *반드시 발생*. 해결 완료 보장은 아님. 단, 고장 1 해결 못 하면 진행할 수 없으므로 힌트/교정 경로를 제공. 가속/추격 게임오버를 고장 2 발동 전에는 확정하지 않는 **게임 디자인 보호 구간** 도입. 고장 2 발동 후 체포는 허용. 이때 시각적 경찰 속도를 조정하여 거리 m와 실제 3D 장면 불일치 방지.

## 경찰거리
한 코스 내 진행 호길이 s를 사용해 `separationM = max(0, playerProgressM - policeProgressM)`로 표현. 경찰이 플레이어 뒤에 있을 때 유효. 렌더 위치·주행속도·간격은 공통 추격 시스템 1개에서 동기화. 커브는 path arc length 사용. 경찰 앞지름·지름길/충돌은 별도 설계. 퍼즐 오답이라고 거리 숫자를 임의로 차감하지 않는다.
진단 중 호빵이는 저속 보조주행 시각/물리 연출 유지. 플레이어 운전과 마우스 퍼즐 동시 조작 금지. 경찰의 접근 속도는 난도와 추리 소요 시간에 따라 제한(일례 0~1m/s 상대속도, 미승인). 2번째 고장 이후 체포 가능.

## 리셋과 예외
- ESC·창 포커스 상실: 실제 물리·거리·타이머 일시정지.
- 증거 부족: 필수 관측 재생/힌트; 자동 정답 결정 금지.
- 잘못된 블록 연결: 형식 오류는 선 연결 즉시 거부; 의미상 잘못된 계산은 테스트에서 실패해야 함.
- MODEL_ERROR: 테스트 데이터 오류, 단위 불일치, NaN, 모델 로딩 실패 등. 플레이어 FAIL로 처리하지 않음.
- 검증 FAIL: 로직 작업대 복귀, 증거와 이전 검사 결과 유지.
- OTA 실패: 유효한 이전 안전 상태 유지. 시각적 전송/활성화 게임 연출이며 실차 주행 중 중요 ECU 펌웨어 교체 절차가 아님.
- 물리 부품 고장: 소프트웨어 진단→코믹한 부품 교체/수리 연출→수리 상태 적용→회귀. SW 수정만으로 물리 파손이 치료되지 않음.
