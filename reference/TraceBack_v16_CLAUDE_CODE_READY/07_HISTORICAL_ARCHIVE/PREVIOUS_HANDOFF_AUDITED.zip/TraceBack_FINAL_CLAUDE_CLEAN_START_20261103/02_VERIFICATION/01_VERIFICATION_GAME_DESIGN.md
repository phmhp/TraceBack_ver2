# '고치기'뿐 아니라 '검증한다'를 게임의 핵심 행동으로

## 세 화면 (Stitch에 이미 시안 존재)
08-01 BOARD: 관측된 증상과 예상/관측 차이 파악, 어느 신호를 더 열면 두 원인을 구분할지 선택, 증거의 지지/반박 연결, 수정 대상 잠정 특정.
08-02 BENCH: 요구사항 **한 문장**을 읽고, 완성 정답 Flow Chart가 아닌 **빠진 제어 블록/잘못된 연결**을 HW 센서·ECU·액추에이터와 함께 배치. 블록의 단위/타입과 의미를 구분해 판정. 의미상 틀려도 시험대로 전송 허용.
08-03 TWIN BENCH: 기준 제어/플레이어 구성 제어의 같은 입력 조건 비교. 테스트 카트리지 2~3개 중 적절한 조건 선택. 실제 계산→차이 확인→시험 불일치 원인 분류→로직 수정→이전 정상 동작 회귀. 기존 08-03 디자인을 교체하지 말고 계산 연동과 인터랙션만 추가.

## 사건마다 서로 다른 주검증 학습
- 사건1: 어떤 **관측 신호**가 SW 판단과 물리적 액추에이터 실패를 구분하는가? 신호 선택·사전 기대값·토크 제한 조건 검증.
- 사건2: 시간 순서·이전 상태·히스테리시스·명령 vs 피드백, 정상 복귀. 일시점 값 비교로 검증하지 않음.
- 사건3(optional): BMS 충전 한계→회생 허용량→마찰제동 보완. 복수 제어기 통합 경계값과 기능 간 연동을 관찰.

## 시험의 3가지 **관점**, 실제 인증 아님
- logic/unit-like: ECU의 구성된 제어 블록 입력→출력 기대값
- interfaces/integration-like: BMS→VCU 또는 thermal→torque signal의 단위·유효성·타이밍·변환
- plant/system-like: ECU `command`→단순화 액추에이터 `feedback`→차량 반응
실제 SWE.4/SWE.5/SWE.6/SYS.5 시험이나 HIL을 수행했다고 주장 금지. 세 관점은 시험 대상 범위가 다를 뿐 차량 설계의 4층과 완전한 1:1 대응이 아님.

## 실험 게임화 규칙
- 실험은 긴 숫자 입력폼이 아니라 **짧은 물리적 카트리지**(정상·경계·고장/복귀)로 선택.
- 선택 전 '무엇이 달라질까?' 예측 1개. 선택이 틀려도 새로운 단서·힌트 획득; 퍼즐 진행 무한 봉쇄 금지.
- `PASS`는 하나의 요구사항/시험 케이스 통과. `VERIFIED/REFUTED/INCONCLUSIVE/MODEL_ERROR`는 가설의 증거 판정이며 다른 상태.
- 실행이 실패한 경우 신호 입력, ECU 명령, 액추에이터 피드백 중 어디를 더 확인할지 선택. 한 사건에 한두 번만, 반복 객관식 억제.
- 고장 수정 시험 PASS와 정상 회귀시험 PASS를 둘 다 기록해야 OTA/수리 이벤트 승인. 모델 로딩 실패는 점수 페널티 없음.
- 실제 HW 고장에서는 올바른 SW 명령이라도 feedback mismatch를 허용; HW 수리 연출 후 대응하는 정상 시험 통과.

## 모든 테스트 케이스 최소 필드
`testId, requirementId, scenarioId, scope(logic|interface|plant), inputSequence[{tMs,signals}], expectedOutputs[{signal,unit,rangeOrValue,tolerance}], observedOutputs, inputProvenance, modelVersion, verdict, evidenceIds`.
확정되지 않은 값은 `UNVERIFIED`로 표시. 근거 없는 실제 ECU 데이터처럼 숫자 창작 금지.
