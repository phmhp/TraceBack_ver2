# EV 도메인과 기본 소프트웨어 제어 골격 — 전부 '배경 모델/차고 탐험' 제공

| ID | 도메인 | 핵심 신호·판단 골격 | 기존 SelectiveKit | 프로토타입 플레이에서 |
|---|---|---|---|---|
| BMS | SOC·온도·전압 유효성 → 사용 가능 상태 → 충/방전 전력 한계 → 보호 | 부분만 존재 | 차고와 구동·제동 가용 신호 |
| HV | 인터록·절연·접촉기 피드백 → PRECHARGE/READY/FAULT | READY Boolean 위주 | 차고 계층 설명 및 READY 가드 |
| VEHICLE_MODE | OFF/INIT/READY/DRIVE/DEGRADED 상태·복귀 | 참고 코드 일부 | 레이싱과 구별되는 vehicleMode |
| GEAR | 요청·차속·브레이크 허용 → 실제 기어 상태 | Boolean/인터록 일부 | 차고/구동 허용 |
| PROPULSION | 페달 A/B·신선도 → DriveAllow → 토크 맵/상한 → RateLimit → 명령·피드백 | `torqueModel` 참고/단순 액추에이터 사례 | **사건1** 핵심 |
| BRAKING | 제동 요구 → 회생 가능량(BMS) → 마찰 보완 → 총 응답 | 단순 제동 요청 | **사건3 선택형** (추가 모델 필요) |
| EPS | 조향 토크·차속 → assist LUT → 제한 → EPS 명령·피드백 | 각도 변환/단순 명령 | 차고·주행, 사건 제외 |
| THERMAL | 온도 유효성→히스테리시스→팬/펌프→보호→명령·응답 | 단일 임계값 | **사건2** 핵심 (시간 상태 필요) |
| LV_DC_DC | HV 가용성·LV 전압→DCDC enable→모니터·부하 보호 | 단순 Bool | 차고 개요 |
| DIAGNOSTICS | range/timeout/plausibility/debounce/command-feedback/recovery | 흩어진 일부 | 사건별 공통 근거 |
| INTEGRATION | BMS power limit→VCU torque; BMS charge→regen; thermal derating→torque | 일부 그래프 | 쌍둥이 시험대 인터페이스 관점 |

## 범위의 진실
이 목록은 자동차의 모든 시스템이 아니다(충전·OBC, ABS/ESC, ADAS, 차체 기능 등 일부 제외). '현재 게임의 EV 핵심 제어 도메인' 전체를 다룬다는 의미다. 전체 도메인의 상세 구현·이상 주입·고장 사건이 이미 준비된 것은 아니다.

## 코드 강화 우선순위
공통 단위/포트/샘플시간 명세 → torque/thermal 실제 엔진 → 3번째 제동 협조 → BMS 충방전 한계 → 상태기/기어/HV → EPS/LV → 통합·진단. 모델이 새 버전으로 도착하면 최신 파일에 맞춰 KEEP/ADAPT/REPLACE 결정.
