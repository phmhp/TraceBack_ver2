/** Contract only, NOT an implementation or verified existing API. */
export type Signal = {id: string; value: number | boolean; unit: string; valid: boolean; tMs: number};
export type RunTestResult = {
  status: 'COMPLETED' | 'MODEL_ERROR' | 'INCONCLUSIVE';
  requirementId: string; testId: string; scenarioId: string; modelVersion: string;
  scope: 'logic' | 'interface' | 'plant';
  passed: boolean | null;
  input: Signal[]; expected: Signal[]; actual: Signal[];
  issues: string[];
};
export interface VehicleControlAdapter {
  listDomains(): string[];
  getComponentGraph(scenarioId: string): unknown;
  getSignalDictionary(): Signal[];
  getEditableProgram(scenarioId: string): unknown;
  validateProgram(scenarioId: string, program: unknown): string[];
  runTest(scenarioId: string, program: unknown, testId: string): RunTestResult;
  getProvenance(): {name:string; version:string; status:'EDUCATIONAL'|'VERIFIED_SOURCE'};
  getSupportedScopes(): Array<'logic'|'interface'|'plant'>;
}
