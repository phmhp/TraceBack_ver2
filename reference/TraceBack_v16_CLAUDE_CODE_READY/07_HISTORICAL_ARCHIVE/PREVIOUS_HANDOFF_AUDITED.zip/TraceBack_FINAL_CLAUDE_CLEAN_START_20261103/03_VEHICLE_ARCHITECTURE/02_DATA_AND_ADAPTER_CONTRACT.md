# 기존 제어 코드가 교체되어도 화면과 게임을 유지하는 경계

## 1개의 VehicleControlAdapter 인터페이스
`listDomains()`, `getComponentGraph(scenarioId)`, `getSignalDictionary()`, `getEditableProgram(scenarioId)`, `validateProgram(program,scenarioId)`, `runTest(scenarioId,program,testId)`, `getProvenance()`, `getSupportedScopes()`.
각 테스트 결과는 아래 JSON 샘플과 `04_SCENARIOS/SCENARIO_SCHEMA.json` 참조.

## 절대 금지
- 모델의 API를 UI에서 직접 호출하거나 `actuator-lab/engine.mjs`의 입출력 key를 화면에 하드코딩.
- 계산하지 않은 시험에 `PASS` 표시, 숫자·신호 단위 임의 창작.
- 새 엔진과 이전 엔진의 시험 결과를 무조건 합쳐 평균내기.
- `command`를 `feedback`으로 별도 검증 없이 복제하고 이를 물리 응답이라 명명.

## 교체 순서
1. 새 ZIP을 `07_LEGACY_LOGIC/REPLACEMENT_INBOX/` 옆에 두고 기존 파일 삭제 없이 diff.
2. 새 소스의 `package/entry/export`, 시간 처리, 데이터 단위, 테스트, API 계약만 확인.
3. 동일 테스트 카트리지 입력에 대해 현재/새 엔진 출력 기록.
4. 변경된 신호 이름·단위·시간 기저·안전 동작은 명시적 `migration-map.json` 작성.
5. 어댑터에서만 구현을 교체. 게임 UI/사건 흐름·에셋은 변경하지 않음.
6. 자동 회귀 테스트 후 테스트 fixture도 새 모델 출처를 기재하여 승인.

## 준비 파일
`signal_dictionary.json` (id, displayName, unit, dataType, sampleTimeMs, producer, consumer, validity), `component_graph.json` (nodes/typed edges and scope), `model_manifest.json` (origin/version/LICENSE), `test_vectors.json` (normal/boundary/fault/recovery sequences).
필요한 파일이 없다면 UNKNOWN으로 남기고 최신 모델 개발 완료 후 채운다.
