# 원본 4개 ZIP의 사용·포함 정책

1. Stitch (2): 10 mockups / 원본 ZIP 포함
2. Stitch (3): 12 mockups / 원본 ZIP 포함
3. CleanStart SelectiveKit: 7 mjs + 4 ts 등 / 원본 ZIP 포함
4. Organized 3: 원본 171 MB, 별도로 보관. 이 스타터 ZIP에 전체 포함하지 않음. 원본에서 직접 선택한 소수 이미지와 원본 `asset-map.json`만 포함.

원본을 전체 다시 첨부할 필요가 없도록 `CURATED_ASSETS.csv`에 원본 ZIP의 정확한 경로를 남겼다. Claude가 썸네일/선별 에셋만 먼저 보고 필요할 때 원본에서 특정 파일만 가져온다.
