# 세 사건 후보 — 최종 신호/원인/정답은 모델 확인 전 미확정

## Fault 1 REQUIRED — 추진/가속 반응 이상
**게임 연출**: 페달 요구는 정상인데 속도가 기대보다 느림. **가설 후보**: ECU가 토크를 낮게 명령했는지, 모터가 정상 명령에 반응하지 않는지. **신호**: pedal, demandTorque, availableTorque, torqueCommand, motorFeedback (원본 코드 이름 아님). 원인 후보 구분이 실제 모델에서 성립할 때만 채택.
**SW 퍼즐**: InputValidity → DriveAllow → AvailableTorqueLimit / Min → Command 중 하나의 잘못된 판단·연결 교정.
**검증**: 정상·제한 경계·구동 금지. command와 feedback 구분. 케이스별 기대값/시간은 최신 모델에서 확정.

## Fault 2 REQUIRED — 열관리 제어 이상
**게임 연출**: 냉각팬이 임계값 근처에서 빠르게 반복 ON/OFF하거나 명령과 실제 반응이 불일치. **SW 후보**: 단일 임계값/이전 상태 누락; **HW 후보**: fan actuator failure (SW만 고쳐서는 복구되지 않음). 양자택일할 때 실제 신호가 구분 가능해야 함.
**SW 퍼즐**: 온도 읽기→ON threshold→OFF threshold→memory state→fan command; 명령/피드백 배선.
**검증**: 온도 상승→하강 시퀀스/경계/정상 복귀. 시간 step, 이전 상태, expected 팬 피드백이 필요. 원본 v3 단일 임계 모델 그대로는 해당 사건을 재현할 수 없음.

## Fault 3 OPTIONAL — 회생·마찰 제동 협조
**게임 연출**: 배터리 충전 허용이 줄어 회생제동이 제한되는데 마찰제동 보완이 부족해짐.
**SW 퍼즐**: TotalBrakeDemand→AvailableRegen→Min(Regen)→FrictionDifference→Result. 배터리 한계와 Brake ECU 인터페이스 확인.
**검증**: 일반 회생 / 제한 / 불가 + 정상 회귀; 총 제동 요구와 실제 반응을 다른 단위로 혼동 금지. 현재 SelectiveKit에 완성된 배분 로직이 없으므로 새 제어 모델/테스트가 준비되기 전 기술상 미승인.

## 최소 승인 게이트(모든 사건)
- 요구사항 ID, 차량 설계층/관련 ECU/SWC, 현상의 **관측**과 원인의 구분
- 주입된 결함이 모델에서 재현되고 수정 후 기대 신호가 바뀜
- 스위치/스텝과 신호 단위, baseline·fault·corrected trace 검증
- 서로 구별되는 가설 2개 및 실제로 구별하는 관측/실험 1개 이상
- 기존 정상 요구를 훼손하지 않는 회귀 시험
- 모델 버전·예시 출처·안전 응답/제한 해제 규칙
- 적어도 2개 사건이 서로 다른 실제 결함 ID로 관리되며 한 run에서 각각 1회 발동
