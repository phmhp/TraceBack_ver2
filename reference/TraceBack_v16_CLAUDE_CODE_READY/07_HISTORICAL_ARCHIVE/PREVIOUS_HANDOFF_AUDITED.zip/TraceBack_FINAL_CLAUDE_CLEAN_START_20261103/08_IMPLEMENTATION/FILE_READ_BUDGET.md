# Claude Code token budget / context reading strategy

**금지**: 기존 Github repo clone / 전체 npm dependency dump / 171MB 원본 에셋 전체 압축 해제 후 모든 이미지 탐색 / 22개 Stitch HTML 통째로 context에 복사 / 모든 `.md` 한꺼번에 읽기.

**PASS1 읽는 순서**
1. `00_START/README_FIRST.md` + `00_START/01_DECISION_LOCK.md`
2. `01_GAME_DESIGN/01_ONE_PAGE_VISION.md` + `01_GAME_DESIGN/02_GAME_STATE_AND_CHASE.md`
3. `01_GAME_DESIGN/03_GARAGE_FOUR_LAYER_TUTORIAL.md` + `01_GAME_DESIGN/04_HARBOR_WORLD_AND_ART.md`
4. `02_VERIFICATION/01_VERIFICATION_GAME_DESIGN.md` + `03_VEHICLE_ARCHITECTURE/02_DATA_AND_ADAPTER_CONTRACT.md`
5. `05_UI_WIREFRAMES/STITCH_SCREEN_INDEX.csv`에서 필요한 한 화면의 원본 ZIP `code.html`을 지정해 단독 읽기. 이미지 먼저 확인, HTML은 화면 컴포넌트 뼈대가 필요한 경우만.
6. `06_ASSETS/ASSET_DOCUMENTATION/CURATED_ASSETS.csv`에서 필요한 asset ID를 확인한 뒤 `SELECTED_REFERENCE`의 특정 1~2개만 열기.
7. `07_LEGACY_LOGIC/SELECTIVE_KIT_ORIGINAL.zip` 안의 `legacy_runtime/engine.mjs`, 실제 쓰는 example, 세 테스트 우선. 깊은 Torque가 필요할 때만 reference TS 파일 읽기.

**PASS2**: `STATUS.md`, `REPO_MAP.md`, 현재 수정 파일, 신규 로직만 추가로 읽는다. 처음부터 모든 파일 재독해하지 않는다.

**파일 산출**: 프로젝트 루트에 `STATUS.md` (현재 작동/실패/후속), `REPO_MAP.md` (실제 구현 경로), `OPEN_ISSUES.md` (기술적으로 막힌 곳)만 계속 갱신.
