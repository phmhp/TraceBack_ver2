# TRACEBACK — CLEAN START HANDOFF (2026-11-03)

**본 ZIP은 신규 구현을 위한 실제 소스·디자인 레퍼런스·계약 문서 묶음이며, 플레이 가능한 완성 게임이 아니다.**

## 사용자가 제공한 입력 4종
- Stitch 화면 ZIP (2): 10개 HTML/PNG 목업
- Stitch 화면 ZIP (3): 12개 HTML/PNG 목업
- TraceBack CleanStart SelectiveKit: 7 `.mjs` + 4 `.ts` 등 선별 로직/테스트/계약
- TraceBack Organized 3: 원본 약 171MB, 511개 유효 항목 + Mac metadata/과거 버전 등. 본 패키지에는 **선별 레퍼런스만** 내장했고 전체 ZIP은 원본 사용자 보관용.

## 반드시 기억
- **기존 GitHub 저장소 전체를 검색/읽지 말 것.** 새로운 폴더에 신규 프로젝트 생성. 소스 코드가 필요하면 이 패키지의 `07_LEGACY_LOGIC`만 inspect.
- `07_LEGACY_LOGIC/SELECTIVE_KIT_ORIGINAL.zip`이 현재 제어 로직 **기준 버전**이다. 사용자는 곧 다른 대화에서 수정된 제어 로직을 전달할 예정. 현재 소스의 계산값·API를 게임 규칙의 절대적 진실로 동결하지 않는다.
- 3D 캐릭터/차량/항구 환경의 완전한 3D 모델은 포함되지 않았다. 이미지·SVG는 레퍼런스 또는 UI 요소이며, 3D mesh/rig/animation과 동일시하지 않는다.
- 외부 표준/실차 인증을 했다고 주장하지 않는다. 교육용 추상 모델을 사용한다.

## 문서 우선순위 (충돌 시)
1. `00_START/01_DECISION_LOCK.md` 현재 확정된 게임 요구
2. `01_GAME_DESIGN` + `02_VERIFICATION` + `03_VEHICLE_ARCHITECTURE` 현재 최종 계약
3. `04_SCENARIOS`와 검증된 실제 로직 어댑터/테스트
4. `05_UI_WIREFRAMES` 원본: **시각 배치 참고만**
5. `06_ASSETS`: 시각 아이덴티티 레퍼런스/선택 소품
6. `07_LEGACY_LOGIC`의 구형 문서와 임의 데모 수치

## Claude Code 첫 시작
1. `08_IMPLEMENTATION/CLAUDE_PASS_1.md` 전체를 읽고 `08_IMPLEMENTATION/FILE_READ_BUDGET.md`를 준수.
2. PASS1: 미니 3D 레이싱 + 차고 4층 탐색 + *고장 1개의 진짜 데이터 연동*까지 수직 슬라이스. 소스 없는 기능은 샘플 상태를 교육용 데모로 표시하고 함부로 PASS 판정 금지.
3. PASS2: 사용자가 업데이트할 로직을 인터페이스 뒤에 교체, 고장2+선택형3/종결/품질·회귀테스트 확장.
4. 기존 파일/캐릭터/시나리오 오류를 발견하면 사용자에게 매번 장황한 질문을 하기보다 `OPEN_ISSUES.md`에 막힌 부분만 기록하고 나머지 승인 범위 구현.

## 빠른 확인
- `05_UI_WIREFRAMES/STITCH_SCREEN_INDEX.csv`: 원본 화면 22개와 새 씬 대응
- `05_UI_WIREFRAMES/STITCH_OVERVIEW.jpg`: 보기용 축소 목록 (실제 원본보다 품질 낮음)
- `06_ASSETS/ASSET_DOCUMENTATION/CURATED_ASSETS.csv`: 초기 개발에 가져갈 이미지의 역할과 승인 범위
- `06_ASSETS/ASSET_DOCUMENTATION/asset-map.original.json`: 원본 에셋 경로·역할
- `07_LEGACY_LOGIC/SOURCE_AUDIT.md`: 재사용 소스·의존성·테스트 한계
- `09_TESTS/ACCEPTANCE.md`: 실제 조작 가능·학습 결과 합격 기준
