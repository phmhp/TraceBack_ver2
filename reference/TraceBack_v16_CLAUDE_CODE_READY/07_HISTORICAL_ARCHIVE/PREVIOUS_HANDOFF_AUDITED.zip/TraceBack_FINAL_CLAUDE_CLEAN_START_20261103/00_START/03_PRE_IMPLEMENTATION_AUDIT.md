# TraceBack — Claude Code 인계 전 검증감사 및 추가 계약
검토일: 2026-11-03
근거: `TraceBack_FINAL_ClaudeCode_Handoff_20261103.zip`에 포함된 문서/SCENARIO_SCHEMA/VehicleControlAdapter 예시/README/프롬프트/QA. 현황은 **정적 명세 감사**이며 3D 게임 빌드 검증이 아님.

## 1. 종합 판정
- 게임의 3화면(BOARD→BENCH→TWIN_TEST), 차고 4설계 관점, 신호 m, 필수 2회 이벤트, 선택형 3회, 새 프로젝트, 자료 읽기 제한은 **명세에 존재**.
- 첫 번째 사건의 실제 결함 주입·요구사항 오라클·입력 시퀀스는 **미확정**. 실행 가능한 첫 전체 사이클을 요구하면서도 이를 구현 가능하게 하는 데이터는 없음. 이를 메우기 위한 `DEMO_ABSTRACTION` 방침이 존재하지만 PASS의 의미/기술적 출처 혼동 위험이 있음.
- 따라서 **디자인·엔진 프로토타입은 즉시 착수 가능**, **정식 검증적 사례 및 2/3 고장 게임 완성은 신규 제어 모델 검수 후**.

## 2. 개념 용어
- 축 1 설계: Vehicle/System, E/E Architecture, ECU SW Architecture, SW Detailed Design.
- 축 2 검증 수준: SWE.4 unit verification, SWE.5 software component verification & integration verification, SWE.6 software verification, SYS.4 system integration & integration verification, SYS.5 system verification (ASPICE 4.0).
- 축 3 실행 방식: MIL, SIL, PIL, HIL 및 실제 시험. 게임의 logic/interface/plant는 세 **교육용 시험 범위**이지 SWE 단계나 MIL/SIL/PIL/HIL 인증 표시 아님. 브라우저 JS 계산을 HIL, 실제 ECU embedded test라고 주장 금지.

## 3. 검증 행동 종합 분류 (사용자가 선택/관측/판정해야 게임화가 됨)
|영역|대표 실무 검증 사고|게임화 위치|우선순위|
|---|---|---|---|
|요구사항 이해|요구, 예외, 허용한계 해석|작업대 메모|P0|
|요구 추적성|REQ↔로직↔테스트↔결과|보드/결과 도장|P0|
|시험 조건 선택|어떤 자극이 결함을 드러내나|카트리지 선택|P0|
|경계값/등가|경계 양쪽, 대표 조건|시험대|P0|
|Negative/fault injection|무효 센서·타임아웃·안전 상태|시험대|P0|
|테스트 오라클|예상값의 출처와 tolerance|시험대|P0|
|실패 분석|입력/통신/ECU/Actuator/환경 분리|보드/시험대|P0|
|변경 영향·회귀|수정 뒤 정상 요구를 망가뜨렸나|시험대 복귀|P0|
|인터페이스 계약|단위, 형식, 주기, 유효성, 신호 방향|차고/시험대|P1|
|상태·시간|전이, debounce, timeout, hysteresis|열관리 사건|P1|
|안전/보호|고장 검출·완화·제한 유지|사건/수리|P1|
|커버리지|어떤 분기/요구가 아직 미검증?|시험대 카트리지 빈 슬롯|P1|
|시험 환경 타당성|설정 오류 vs 대상 SW 결함|실패 분석|P1|
|신호 기록·재현성|같은 입력/버전으로 재시험|리플레이/로그|P1|
|변형 테스트|조건 하나만 바꾸어 인과 확인|카트리지 선택|P1|
|통합/시스템 관점|ECU 간 및 차량 응답의 경계에서 확인|시험대 2/3층|P1|
|진단 상태|DTC, debounce, healing, timeout 등|상급 사건|P2|
|정적 검증|코드 리뷰·규칙 준수·정적 분석|선택형 차고 보조|P2|
|동적 분석|실행 시간/자원/통신 지터|추후 확장|P2|
|장시간/강건성|지속 고장, 간헐 고장, 전원 재시작|추후 확장|P2|
|현물/타깃 시험|SIL/PIL/HIL/차량 시험|게임내 개념 카드만|P2|

## 4. 인계 차단 우선순위 (감사 이슈)
### P0 — Claude를 투입하기 전에 명확히 고쳐야 할 항목
1. **첫 사건의 정답 없음**: `04_SCENARIOS/SCENARIO_SCHEMA.json`은 `UNVERIFIED` 더미 값. `FAULT1_FIXTURE`의 요구사항/기준 그래프/결함 그래프/변경 가능 블록/두 가설/실험/정상·경계·고장·회귀 oracle을 적어도 하나의 *교육용 검증 fixture*로 고정하거나, 모델 도착까지 데모 경로만 구현하도록 명시해야 함.
2. **구현-데모 출처 표시 충돌**: `PASS1`은 '실제 데이터 연동'을 요구하지만 실제 fault data 미확정, DEMO_ABSTRACTION 허용. 정식 교육 검증 PASS와 데모 통과를 UI/로그에서 별도 상태로 명시해야 함. 시연용 fixture의 내부 요구사항에 대한 PASS는 가능하나 '검증된 차량 모델'이라 주장 불가.
3. **VehicleControlAdapter 시간/상태 계약 미비**: 메서드 서명에 초기조건, `dt/sampleTime`, 단계별 신호 trace, 이전 상태, 시간축 reset/복귀, 정확한 deterministic evaluation, fault injection, actuation-feedback/plant API가 없음. 열관리 hysteresis와 통합/차량 응답은 이대로 일관 실행 어렵다.
4. **기준 모델과 후보 비교가 곧 검증은 아님**: reference 신호의 요구사항/제어원리 출처, 기대값·허용오차·조건 선택을 명시. 변경 그래프가 '올바른 기준 모델과 비슷함'이 아니라 요구사항에 부합해야 PASS.
5. **원인 선택 vs SW 수정 불일치 가능**: 물리 고장이라면 SW 블록 수정만으로 고칠 수 없으며 수리 전/후 각 검사 결과·수리 gate 별도 필요. 안전 보호를 해제하여 가속 회복하는 것을 정답으로 허용하지 말 것.
6. **필수 고장 2회 보장 vs 조기 종료**: 두 번째 고장 '발생' 전에는 체포 종료를 차단하는 설계가 있으나, 1번 사건 막힘·스킵·시나리오 데이터 실패·강제 종료로 2번 발동이 막히는 예외는 처리 정책 부재. 미완성 자료로 무한 반복/가짜 완료를 만들지 않게 처리.
7. **실제 스타터에는 유저 편집 그래프 실행기 없음**: `07_LEGACY_LOGIC`의 기본 v3 엔진은 repair candidate 선택. 이전 별도 코드 패치가 이번 ZIP에 없음. Claude가 `getEditableProgram`이 구현됐다고 오인하지 않도록 새 그래프 실행기가 PASS1 필수 산출물임을 강조하고, 실행 테스트로 검증.
8. **수정과 인터페이스/Plant 시험의 실체 부족**: `getSupportedScopes()` 문자열 배열만으로 물리 응답·실제 ECU 간 데이터 전달이 존재하지 않음. interface/plant 미구현이면 `NOT_IMPLEMENTED` 표시하고 fake success 금지.

### P1 — 첫 실행에서 구체 지시할 것
9. 실제 재생 규칙: 추격 진행과 보조주행 속도/시간 상태/이동 경로, 경찰이 앞질렀을 때의 distance 처리, pause/focus, 프레임율 독립 고정 update; 현 `max(0,playerProgress-policeProgress)`는 추월 후 부호 손실.
10. 예측 카드/시험 실행: 유저가 '무엇이 달라질지'를 언제 제출하고, 오답일 때 어디로 가는지, 케이스 통과와 가설 지지/반박이 어떻게 다른지 상세 상태전이 누락.
11. 화면/에셋 매칭: 22개 HTML이 어느 실제 씬/상태/중복 컴포넌트로 가는지는 CSV에 있지만 대표 08-01~03 화면의 버튼 활성/disabled/힌트/error 세부가 단독 실행 가능한 인터랙션 계약으로 완성되진 않음.
12. 아트·모델 한계: 캐릭터/자동차 3D 원본 없음. proxy 허용과 승인 모델 대체 조건, 라이선스/배포 근거 없음. 맵은 상세 연출 가이드만 있고 실제 통과 가능한 경로 구조/충돌 규격 미정.
13. 도메인 과대표현: 카탈로그의 전체 도메인은 모두 상세 시뮬레이션이 아님. `CATALOG_ONLY|BASIC_EXECUTABLE|FAULT_TESTABLE`의 구현 레벨 표시 필요.
14. 학습성과: 게임 목표 5개와 각각의 플레이어 행동 및 테스트 성공 지표 연결은 느슨함. '안전 제한은 왜 정답인가', '어떤 신호가 가설을 구분하나' 질문별 최소 증거를 scenario에 추가.
15. 48h 범위: 첫 고장 실제 진단 루프, 4단 차고, 풍성한 3D 항구, 추격 물리, 세 시험 범위, 두 고양이 애니메이션 동시 구현은 과다. PASS1은 단일 동작 가능한 수직 슬라이스로 종료; PASS2는 첫 슬라이스를 망가뜨리지 않는 범위에서 확장.

## 5. 권장 '한 사건' 계약 (모델 업데이트를 기다리면서도 진행할 기준)
- reqId / 4설계 관점별 component&signal ID
- 명시적인 정상 그래프 + 결함 그래프 + 바꿀 수 있는 블록·엣지 목록
- 관측 증상과 사실인 신호, 의심 원인 2개, 구별 시험 1개
- 입력 자극 시퀀스와 `expected` (단위/오차/시간창/요구사항 근거)
- command / interface / feedback / plant output 각각 구분
- 테스트 결과 `PASS/FAIL/INCONCLUSIVE/MODEL_ERROR/NOT_IMPLEMENTED` 분리
- 고장/경계/정상/복귀별 최소 1개 시퀀스 (게임 노출은 2~3개 카트리지)
- 가설의 지지/반박 판단과 test PASS/FAIL 분리
- 수리 유형에 따라 SW 교정 그래프 혹은 HW 부품 수리 플래그 및 후속 검사
- 비교 전 요구사항, reference model, candidate model의 provenance/version 고정

## 6. Claude Code 첫 작업 방침
1. 최신 전달본 전부 한 번에 읽지 말고 `README`, `DECISION_LOCK`, `FILE_READ_BUDGET`, 이 감사를 확인.
2. 로직 업데이트 예정: 구현 중 어댑터를 우선 분리. `runTest()`로 반환하는 응답에는 scope 지원 여부와 trace/오라클 provenance가 있어야 함.
3. 데이터가 미확정이면 `DEMO_ABSTRACTION`로 제한한 검증 가능한 self-contained fixture를 하나 만들어 UI/구조 테스트만 가능하게 하라. 해당 fixture는 실제 자동차 제어 정답과 차이가 있는 경우 명시.
4. 화면 만들기 전에 첫 시나리오의 정상/결함/수정 그래프와 오라클을 테스트로 고정하고, 같은 신호와 시간기저를 UI로 연결.
5. PASS1 완료 수용 조건: 3D 주행 1구간 + 고장 1회 + 메모판 차별 신호 선택 + 플레이어 그래프 출력 차이 + 정상/경계/고장 시험 + 회귀 + 주행 복귀. 실제 브라우저 조작과 테스트 결과를 첨부할 것.
6. 기존 대형 Git 저장소는 읽지 않는다. 로직 교체시 `source package`의 manifest·entry·tests만 보고 API adapter를 수정.
