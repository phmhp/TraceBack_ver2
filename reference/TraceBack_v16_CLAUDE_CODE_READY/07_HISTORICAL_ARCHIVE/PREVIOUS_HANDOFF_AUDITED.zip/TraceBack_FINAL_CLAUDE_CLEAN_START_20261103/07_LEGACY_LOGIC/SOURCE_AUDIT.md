# CleanStart SelectiveKit 정밀 범위 — 코드의 재사용 사실과 한계

본 패키지의 `SELECTIVE_KIT_ORIGINAL.zip`은 사용자 첨부 원본을 그대로 복사한 것. 약 41KB ZIP / 15개 항목.

| 경로(원본 ZIP 내 상대 경로) | 재사용 | 이유/위험 |
|---|---|---|
| `legacy_runtime/engine.mjs` | KEEP+ADAPT | 타입/연결·신호 계산, 고장 주입, 액추에이터 명령 결과. 사용자 편집 그래프 직접 평가 기능은 원본에 없음 |
| `legacy_runtime/examples.mjs` | REFERENCE | 추진/제동 교육용 간단 수식. 실제 복합 제동 완성 아님 |
| `legacy_runtime/domain-examples.mjs` | REFERENCE+ADAPT | BMS/HV/gear/steer/thermal/LV 등의 기초 케이스. 시간·feedback·보호 모두 완성된 것 아님 |
| `legacy_runtime/integration.mjs` | ADAPT | 조사·후보 수리·시험 래퍼, 게임 메모판/블록 편집기와 동일하지 않음 |
| `reference_only/torqueModel.ts` | ADAPT | 더 깊은 토크 상태·신호 검증. 새로운 UI/adapter와 연결 검토 |
| `reference_only/signalBlocks.ts` | ADAPT | 더 다양한 블록/시간 연산. 기존 v3 actuator engine과 자동 호환 아님 |
| `reference_only/domainTraining.ts` | READ-ONLY | 기존 프로젝트의 타입 참조 있음. 바로 import하지 말 것 |
| `reference_only/vehicleArchitecture.ts` | READ-ONLY | 차고지 4층 설계 콘텐츠에 사용할 텍스트/그래프 근거, 양산 E/E 진실의 출처는 아님 |
| `tests/*.test.mjs` | KEEP | 독립 엔진의 단위 회귀 기준 |

**중요:** 이전 대화에서 별도 패치로 만든 '플레이어 직접 로직 블록 실행기'는 본 CleanStart 원본 ZIP에 포함되어 있지 않다. Claude가 기존 선별 ZIP에 구현되어 있다고 오인하지 않도록 한다. 최신 로직 ZIP이 도착하면 그 버전과 비교 후 채택.

**테스트:** 원본 Node 테스트는 본 산출물 생성 시 별도 실행하여 결과를 `09_TESTS/EXTRACTED_LOGIC_TEST_RESULTS.txt`에 기록한다. 이 결과는 게임 UI·브라우저 3D/실차 검증을 의미하지 않는다.
